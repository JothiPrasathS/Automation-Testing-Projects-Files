import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class BusDetail{
	
public static void addBusDetail() {
	
	
	Scanner scanner=new Scanner(System.in);
	System.out.println("BusId: ");
	int BusId=scanner.nextInt();
	System.out.println("Bus Name: ");
	scanner.nextLine();
	String Bus_Name=scanner.nextLine();
	System.out.println("From: ");
	String From=scanner.next();
	System.out.println("To: ");
	String To=scanner.next();
	System.out.println("DepartureTime: ");
	String DepartureTime=scanner.next();
	System.out.println("ArrivalTime: ");
	String ArrivalTime=scanner.next();
	System.out.println("Max_Seat: ");
	String Max_Seat=scanner.next();
	System.out.println("DriverName: ");
	String DriverName=scanner.next();
	System.out.println("Bus Fare: ");
	int Fare=scanner.nextInt();
	System.out.println(" Bus Type: ");
	scanner.nextLine();
	String  Bus_Type=scanner.nextLine();

	Bus bus=new Bus(BusId,Bus_Name,From,To ,DepartureTime,ArrivalTime,Max_Seat,DriverName,Fare,Bus_Type);
	
	try {
	     Connection connection ;
		 String databasename = "bus_db";
		  String url = "jdbc:mysql://localhost:3306/"+databasename;
		  String username ="root";
		 String password ="hari";
		 Class.forName("com.mysql.cj.jdbc.Driver");
	     connection = DriverManager.getConnection(url,username,password);
	     
	     String sql="insert into bus_details(BusNo,Bus_Name,Departure,Destination ,DepartureTime,ArrivalTime,Max_Seat,DriverName,Fare,Bus_Type)VALUES(?,?,?,?,?,?,?,?,?,?)";
	     PreparedStatement st=connection.prepareStatement(sql);
	     
	     st.setInt(1,bus.getBusId());
	     st.setString(2,bus.getBus_Name());
	     st.setString(3,bus.getFrom());
	     st.setString(4,bus.getTo());
	     st.setString(5,bus.getDepartureTime());
	     st.setString(6,bus.getArrivalTime());
	     st.setString(7,bus.getMax_Seat());
	     st.setString(8,bus.getDriverName());
	     st.setInt(9, bus.getFare());
	     st.setString(10,bus.getBus_Type());
	     
	     st.executeUpdate();
	     System.out.println("Bus Detail Added Successfully");
	     select();
	}catch(Exception e) {
		System.out.println(e);
	}
	scanner.close();
}

public static void select() {
	System.out.println("1.Add More Bus  2.Exit\n");
	Scanner sc=new Scanner(System.in);
	int Choose=sc.nextInt();
	if(Choose==1) {
		BusDetail.addBusDetail();
	}
	else {
		Home home=new Home();
		home.accessHome();
	}
	sc.close();
}

}

class Bus {
	private int BusId;
	private String Bus_Name;
	private String From;
	private String To;
	private String DepartureTime;
	private String ArrivalTime;
	private String Max_Seat;
	private String DriverName;
	private int Fare;
	private String Bus_Type;
	
	
	public Bus(int busId, String bus_Name, String from, String to, String departureTime, String arrivalTime,
			String max_Seat, String driverName, int fare, String bus_Type) 
	{
		super();
		BusId = busId;
		Bus_Name = bus_Name;
		From = from;
		To = to;
		DepartureTime = departureTime;
		ArrivalTime = arrivalTime;
		Max_Seat = max_Seat;
		DriverName = driverName;
		Fare = fare;
		Bus_Type = bus_Type;
	}

	public String getBus_Type() {
		return Bus_Type;
	}
	public void setBus_Type(String bus_Type) {
		Bus_Type = bus_Type;
	}
	public int getBusId() {
		return BusId;
	}
	public void setBusId(int busId) {
		BusId = busId;
	}
	public int getFare() {
		return Fare;
	}
	public void setFare(int fare) {
		Fare = fare;
	}
	
	public String getBus_Name() {
		return Bus_Name;
	}
	public void setBus_Name(String bus_Name) {
		Bus_Name = bus_Name;
	}
	public String getFrom() {
		return From;
	}
	public void setFrom(String from) {
		From = from;
	}
	public String getTo() {
		return To;
	}
	public void setTo(String to) {
		To = to;
	}
	public String getDepartureTime() {
		return DepartureTime;
	}
	public void setDepartureTime(String departureTime) {
		DepartureTime = departureTime;
	}
	public String getArrivalTime() {
		return ArrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		      ArrivalTime = arrivalTime;
	}
	public String getMax_Seat() {
		return Max_Seat;
	}
	public void setMax_Seat(String max_Seat) {
		Max_Seat = max_Seat;
	}
	public String getDriverName() {
		return DriverName;
	}
	public void setDriverName(String driverName) {
		DriverName = driverName;
	}

	

	
	
}