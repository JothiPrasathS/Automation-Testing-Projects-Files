import java.sql.SQLException;
import java .util.*;
    	public class Main {
    	    public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
    	    	
    	    System.out.println("Enter Your Choice \n");
    	   System.out.println("1.Registration 2.Login \n");
    	   
    	   Scanner scanner=new Scanner(System.in);
    	   int page=scanner.nextInt();
    	      
    	   if(page==1) {
    	   
    	  SignUp.getDetail(); 
    	   }
    	   
    	   else{ 
    		
    	   Login.getDetail();
    	   }
    	   
    	   scanner.close();
    	    }
    	}
    	/*
    	<suite name="Suite">
    	 <parameter name="Url" value="http://www.amazon.in/"></parameter>
    	 

    	  <test thread-count="5" name="Test Chrome" parallel="classes">
    	  <parameter name="Browser" value="Chrome"/>
    	   <classes>
    	      <class name="com.qa.TestScripts.TC_AmazonSearch_001"/>
    	     </classes>
    	  </test> <!-- Test 1 -->
    	  
    	   <test thread-count="5" name="Test edge" parallel="classes">
    	  <parameter name="Browser" value="edge"/>
    	   <classes>
    	      <class name="com.qa.TestScripts.TC_AmazonSearch_001"/>
    	     </classes>
    	  </test> <!-- Test 2 -->
    	  
    	</suite> <!-- Suite -->
    	*/