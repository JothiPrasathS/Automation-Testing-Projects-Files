import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class PassengerDetail {
static void getPassengerDetail() {
	System.out.println("Press 1 for full List\nPress 2 for single Bus List");
	Scanner scanner=new Scanner(System.in);
	int choose=scanner.nextInt();
	try {
    Connection connection ;
	 String databasename = "bus_db";
	  String url = "jdbc:mysql://localhost:3306/"+databasename;
	  String username ="root";
	 String password ="hari";
	 Class.forName("com.mysql.cj.jdbc.Driver");
    connection = DriverManager.getConnection(url,username,password);
	if(choose==1) {
		

		String sql="select * from bus_db.bus_details";
		Statement st = connection.createStatement();
		ResultSet rs = st.executeQuery(sql);
		while(rs.next()) {
			System.out.println(rs.getString(1)+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+
					rs.getString(5)+rs.getString(6)+" "+rs.getString(7)+" "+rs.getString(8)+" "+rs.getString(9)+" "+rs.getString(10));
		}
		}
	else {
		System.out.println("BusId: ");
		Scanner scanner1=new Scanner(System.in);
		int BusId=scanner1.nextInt();
		
		String query="SELECT bus_details.BusNo,bus_details.Bus_Name,bus_details.Departure,bus_details.Destination,\r\n"
				+ "bus_details.DepartureTime,bus_details.ArrivalTime,bus_details.DriverName,bus_details.Fare\r\n"
				+ ",bus_details.Bus_Type,passenger_detail.Name,passenger_detail.Mobile_Number,passenger_detail.Pickup,\r\n"
				+ "passenger_detail.drop_point,passenger_detail.SeatNo,passenger_detail.Daate\r\n"
				+ "FROM bus_details,passenger_detail\r\n"
				+ "where bus_details.BusNo=passenger_detail.BusNo and bus_details.BusNo="+BusId;
		System.out.println(query);
		Statement st = connection.createStatement();
		ResultSet rs = st.executeQuery(query);
		while(rs.next()) {
			System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+
		rs.getString(5)+rs.getString(6)+" "+rs.getString(7)+" "+rs.getString(8)+" "+rs.getString(9)+" "+rs.getString(10)+
		rs.getString(11)+" "+rs.getString(12)+" "+rs.getString(13)+" "+rs.getString(14)+" "+rs.getString(15));
		}
		scanner1.close();
	}
}catch(Exception e) {
	System.out.println(e);
}
}
public static void main(String[] args) {
	getPassengerDetail();
}
}
