import java.util.Scanner;

public class Home {
	void accessHome() {
Scanner scanner=new Scanner(System.in);
System.out.println("\nWelcome to Home Page\n");
System.out.println("press 1 to Add  New Bus\npress 2 to view BusList \nPress 3 for Passenger Detail \nPress 4 for Logout");
int Access=scanner.nextInt();
switch(Access) {
case 1:{
	System.out.println("Add  New Bus\n");

		  BusDetail.addBusDetail();
		  break;
}
case 2:{
	Buses.getBuses();
	break;
}

case 3:{
 System.out.println("Passenger Details:");
	
	PassengerDetail.getPassengerDetail();
	
}
case 4:{
	System.out.print("Logged out");
}


scanner.close();
	}
	}
}