import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Buses {
public static void getBuses(){
	System.out.print("Bus List\n\n");
	try {
	    Connection connection ;
		 String databasename = "bus_db";
		  String url = "jdbc:mysql://localhost:3306/"+databasename;
		  String username ="root";
		 String password ="hari";
		 Class.forName("com.mysql.cj.jdbc.Driver");
	    connection = DriverManager.getConnection(url,username,password);
		String sql="select * from bus_db.bus_details";
//      PreparedStatement ps = connection.prepareStatement(sql);
		Statement st = connection.createStatement();
		ResultSet rs = st.executeQuery(sql);
		System.out.println("BusNo"+" "+"Bus_Name"+" "+"Departure"+" "+"Destination"+" "+"DepartureTime"+" "+"ArrivalTime"+" "+"Max_Seat"+" "+"DriverName"+" "+"Fare"+" "+"Bus_Type");
		while(rs.next()) {
		System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getString(8)+" "+rs.getString(9)+" "+rs.getString(10));
		}
//		System.out.print("sql");
	}catch(Exception e) {
		System.out.println(e);
	}
}

	}