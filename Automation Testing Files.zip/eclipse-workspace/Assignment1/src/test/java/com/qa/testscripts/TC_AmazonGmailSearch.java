package com.qa.testscripts;

import org.openqa.selenium.Keys;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qa.pages.AmazonGmailPages;

public class TC_AmazonGmailSearch extends TestBase{
	AmazonGmailPages amzgml;
	@Parameters({"Browser","Url"})
	@Test
	public void Search() throws InterruptedException
	{
		amzgml=new AmazonGmailPages(Driver);
		
		amzgml.SearchBox().sendKeys("amazon"+Keys.ENTER);
		
		Thread.sleep(2000);
		
		amzgml.Amz().click();
	  	
  		Thread.sleep(3000);
  		
  		String title1=Driver.getTitle();
  		System.out.println("The Page landed in:"+title1);
  		
  		Driver.navigate().back();

  		Thread.sleep(3000);
  		
  		Driver.navigate().back();
  		
  		amzgml.GmailTag().click();
  	  	
  		Thread.sleep(3000);
  		
  		String title2=Driver.getTitle();
  		System.out.println("The Page landed in:"+title2);
  		
        amzgml.CreateAcc().click();
  	  	
  		Thread.sleep(3000);
  		
        amzgml.FirstName().sendKeys("jothi");
		
		Thread.sleep(2000);
		
        amzgml.LastName().sendKeys("harish");
		
		Thread.sleep(2000);
		
        amzgml.UserName().sendKeys("jothiharissh2510");
		
		Thread.sleep(2000);
		
        amzgml.Password().sendKeys("8754775095");
		
		Thread.sleep(2000);
		
        amzgml.ConfirmPassword().sendKeys("8754775095");
		
		Thread.sleep(2000);
		
		amzgml.ShowPassword().click();
  	  	
  		Thread.sleep(3000);
  		
		amzgml.Next().click();
  	  	
  		Thread.sleep(3000);
  		
//		amzgml.PhoneNo().sendKeys("8754775095"+Keys.ENTER);
//  	  	
//  		Thread.sleep(3000);
//  		
//		amzgml.Nextt().click();
//  	  	
// 		Thread.sleep(3000);
//  		
//	    amzgml.Code().sendKeys("875477");
//
//  		Thread.sleep(3000);
//  		
//	    amzgml.Verify().click();
//  	  	
//  		Thread.sleep(3000);
//  		
//	    amzgml.Agree().click();
//  	  	
//  		Thread.sleep(3000);
  		
}
}