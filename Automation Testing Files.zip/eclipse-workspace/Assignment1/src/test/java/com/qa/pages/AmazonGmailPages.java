package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AmazonGmailPages {

	 WebDriver Driver;
	 
	 @FindBy(xpath="/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input")
	 WebElement searchbox;
	 public WebElement SearchBox()
	 {
		 return searchbox;
	 }
	
	 @FindBy(xpath="//*[@id=\"rso\"]/div[1]/div/div/div/div/div/div/div/div[1]/a/h3")
	 WebElement amz;
	 public WebElement Amz()
	 {
		 return amz;
	 }
	 
	 @FindBy(xpath="/html/body/div[1]/div[1]/div/div/div/div[1]/div/div[1]/a")
	 WebElement gmailtag;
	 public WebElement GmailTag()
	 {
		 return gmailtag;
	 }
	 
	 @FindBy(xpath="/html/body/header/div/div/div/a[3]/span[2]")
	 WebElement createacc;
	 public WebElement CreateAcc()
	 {
		 return createacc;
	 }
	 
	 @FindBy(xpath="//*[@id=\"firstName\"]")
	 WebElement firstname;
	 public WebElement FirstName()
	 {
		 return firstname;
	 }
	 
	 @FindBy(xpath="//*[@id=\"lastName\"]")
	 WebElement lastname;
	 public WebElement LastName()
	 {
		 return lastname;
	 }
	 
	 @FindBy(xpath="//*[@id=\"username\"]")
	 WebElement username;
	 public WebElement UserName()
	 {
		 return username;
	 }
	 
	 @FindBy(xpath="/html/body/div[1]/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div[3]/div[1]/div/div/div[1]/div/div[1]/div/div[1]/input")
	 WebElement password;
	 public WebElement Password()
	 {
		 return password;
	 }
	 
	 @FindBy(xpath="/html/body/div[1]/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div[3]/div[1]/div/div/div[2]/div/div[1]/div/div[1]/input")
	 WebElement confirmpassword;
	 public WebElement ConfirmPassword()
	 {
		 return confirmpassword;
	 }
	 
	 @FindBy(xpath="/html/body/div[1]/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div[3]/div[3]/div/div[1]/div/div/div[1]/div/input")
	 WebElement showpassword;
	 public WebElement ShowPassword()
	 {
		 return showpassword;
	 }
	 
	 @FindBy(xpath="//*[@id=\"accountDetailsNext\"]/div/button/span")
	 WebElement next;
	 public WebElement Next()
	 {
		 return next;
	 }
	 
	 @FindBy(xpath="//*[@id=\"phoneNumberId\"]")
	 WebElement phoneno;
	 public WebElement PhoneNo()
	 {
		 return phoneno;
	 }
	 @FindBy(xpath="/html/body/div[1]/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/div/div[2]/div/div[1]/div/div/button/div[3]")
	 WebElement nextt;
	 public WebElement Nextt()
	 {
		 return nextt;
	 }
	 
	 @FindBy(xpath="//*[@id=\"code\"]")
	 WebElement code;
	 public WebElement Code()
	 {
		 return code;
	 }
	 
	 @FindBy(xpath="/html/body/div[1]/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/div/div[2]/div/div[1]/div/div/button/span")
	 WebElement verify;
	 public WebElement Verify()
	 {
		 return verify;
	 }

//	 @FindBy(xpath="/html/body/div[1]/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/div/div[2]/div/div[1]/div/div/button/span")
//	 WebElement agree;
//	 public WebElement Agree()
//	 {
//		 return agree;
//	 }
	 
	 public AmazonGmailPages(WebDriver Driver)
	 {
		 this.Driver=Driver;
		PageFactory.initElements(Driver,this); 
	 }
}
