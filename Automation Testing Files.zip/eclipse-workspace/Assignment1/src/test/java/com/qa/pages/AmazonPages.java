package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AmazonPages {

	 WebDriver Driver;
	 
	 @FindBy(xpath="//select[@id='searchDropdownBox']")
	 WebElement category;
	 public WebElement Category()
	 {
		 return category;
	 }
	 
	 @FindBy(xpath="//option[contains(text(),'Electronics')]")
	 WebElement electronics;
	 public WebElement Electronics()
	 {
		 return electronics;
	 }
	 
	 @FindBy(xpath="//input[@id='twotabsearchtextbox']")
	 WebElement searchbox;
	 public WebElement SearchBox()
	 {
		 return searchbox;
	 }
	 
	 @FindBy(xpath="//*[@id=\"p_89/Samsung\"]/span/a/div/label/i")
	 WebElement brand1;
	 public WebElement Brand1()
	 {
		 return brand1;
	 }
	 
	 @FindBy(xpath="//input[@id='low-price']")
	 WebElement lowprice;
	 public WebElement LowPrice()
	 {
		 return lowprice;
	 }
	 	
	 @FindBy(xpath="//input[@id='high-price']")
	 WebElement highprice;
	 public WebElement HighPrice()
	 {
		 return highprice;
	 }
	 
	 @FindBy(xpath="//*[@id=\"a-autoid-1\"]/span/input")
	 WebElement go;
	 public WebElement Go()
	 {
		 return go;
	 }
	 
	 @FindBy(xpath="/Html")
	 WebElement all;
	 public WebElement All()
	 {
		 return all;
	 }
	 
	 public AmazonPages(WebDriver Driver)
	 {
		 this.Driver=Driver;
		PageFactory.initElements(Driver,this); 
	 }
}
