package com.qa.testscripts;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qa.pages.AmazonPages;

public class TC_AmazonSearch extends TestBase{
	AmazonPages amz;
	@Parameters({"Browser","Url"})
	@Test
	public void Search() throws InterruptedException, AWTException, IOException
	{
//		Robot robot=new Robot();
		amz=new AmazonPages(Driver);
		
		String title1=Driver.getTitle();
  		System.out.println("The Page landed in:"+title1);
		
		amz.Category().click();
		Thread.sleep(2000);
		
		amz.Electronics().click();
		Thread.sleep(2000);

		amz.SearchBox().sendKeys("Mobile Phone"+Keys.ENTER);
		Thread.sleep(2000);
		
		String title2=Driver.getTitle();
  		System.out.println("The Page landed in:"+title2);
  		
  		JavascriptExecutor js =(JavascriptExecutor) Driver;
  		Thread.sleep(3000);
  		js.executeScript("window.scrollBy(0,5000)");
  		Thread.sleep(4000);
  		
		amz.Brand1().click();
  		Thread.sleep(2000);

		amz.LowPrice().sendKeys("5000");
		Thread.sleep(2000);

		amz.HighPrice().sendKeys("25000");
		Thread.sleep(2000);
  		
  		amz.Go().click();
  		Thread.sleep(2000);
  		
  		String p1= amz.All().getText();
  		System.out.println(p1);
  		Thread.sleep(2000);
  		
//  		TakesScreenshot scrShot =((TakesScreenshot) Driver);
//  		File src1 = scrShot.getScreenshotAs(OutputType.FILE);
//  		File dest = new File("./snaps/img.png");
//  		FileHandler.copy(src1, dest);
  		
//  		amz.SearchBox().click();
//  		robot.keyPress(KeyEvent.VK_BACK_SPACE);
//		Thread.sleep(8000);
//		
//		robot.keyRelease(KeyEvent.VK_BACK_SPACE);
//		Thread.sleep(8000);

  		Driver.navigate().to("http://www.amazon.in/");
		
		amz.Category().click();
		Thread.sleep(2000);
		
		amz.Electronics().click();
		Thread.sleep(2000);
		
		amz.SearchBox().sendKeys("Television"+Keys.ENTER);
		Thread.sleep(2000);
		
  		String title3=Driver.getTitle();
  		System.out.println("The Page landed in:"+title3);

  		String p2= amz.All().getText();
  		System.out.println(p2);
  		Thread.sleep(2000);
  		
	}
}