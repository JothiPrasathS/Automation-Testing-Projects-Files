package com.appium.browserStack;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class LaunchApiDemoApp {
	@SuppressWarnings("unused")
	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		DesiredCapabilities cap= new DesiredCapabilities();
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME,MobilePlatform.ANDROID);
        cap.setCapability("appPackage", "io.appium.android.apis");
        cap.setCapability("appActivity", "io.appium.android.apis.ApiDemos");
		
    	AndroidDriver<MobileElement> driver=new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub/"),cap);
    	Thread.sleep(2000);
    	
    	//id
    	driver.findElement(By.id("android:id/text1")).click();
    	
    	//AccessibilityId
    	driver.findElementByAccessibilityId("App").click();
    	
    	//className
    	List<MobileElement> element= driver.findElements(By.className("android.widget.TextView"));
    	for(int i=1;i<element.size();i++) {
    		System.out.println("Value of element is : "+element.get(i).getText());
    		
    		element.get(i).click();
    		Thread.sleep(2000);
    		driver.navigate().back();
    		Thread.sleep(2000);
    		
    		if(element.get(i).getText().equals("Preference")) {
    			break;
    		}
    	}
}
}