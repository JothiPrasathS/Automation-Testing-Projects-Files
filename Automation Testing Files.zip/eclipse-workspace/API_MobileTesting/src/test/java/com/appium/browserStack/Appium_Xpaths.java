package com.appium.browserStack;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class Appium_Xpaths {
	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		DesiredCapabilities cap= new DesiredCapabilities();
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME,MobilePlatform.ANDROID);
        cap.setCapability("appPackage", "io.appium.android.apis");
        cap.setCapability("appActivity", "io.appium.android.apis.ApiDemos");
    	cap.setCapability(MobileCapabilityType.DEVICE_NAME,"emulator-5554");
		
    	AndroidDriver<AndroidElement> driver=new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub/"),cap);
    	
    	driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
    	
    	
    	//By using index
    	driver.findElement(By.xpath("//android.widget.TextView[@index='4']")).click();
    	Thread.sleep(2000);
    	
    	//By using content-desc
    	driver.findElement(By.xpath("//android.widget.TextView[@content-desc='Storage']")).click();
    	Thread.sleep(2000);
    	
    	//By using resource-id
    	driver.findElement(By.xpath("//android.widget.TextView[@resource-id='android:id/text1']")).click();
    	Thread.sleep(2000);
    	
    	//By using text
    	driver.findElement(By.xpath("//android.widget.Button[@text='Delete']")).click();
    	Thread.sleep(2000);
    	
    	//By using contains
    	driver.findElement(By.xpath("//*[contains(@text,'Pref')]")).click();
    	Thread.sleep(2000);
    	
    	//By using or
    	driver.findElement(By.xpath("//*[@text='7.' or @index='6']")).click();
    	Thread.sleep(2000);
    	
       	//By using and
    	driver.findElement(By.xpath("//*[@text='List preference' and @index='0']")).click();
    	Thread.sleep(2000);
    	
     	//By using AndroidUIAutomator
    	driver.findElementByAndroidUIAutomator("text(\"Alpha Option 01\")").click();
    	Thread.sleep(2000);
    	
    	driver.findElementByAndroidUIAutomator("text(\"Screen preference\")").click();
    	int TotalClickableElements = driver.findElementByAndroidUIAutomator("new UiSelector().clickable(true)").size();
    	System.out.println(TotalClickableElements);
    			
}
}
