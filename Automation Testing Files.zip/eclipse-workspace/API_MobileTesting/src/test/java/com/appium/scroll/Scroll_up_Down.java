package com.appium.scroll;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;

public class Scroll_up_Down {

	public static AppiumDriverLocalService service;
	public static String NodeExePath="C:\\Program Files\\nodejs\\node.exe";
	public static String NodeJsMainPath ="C:\\Users\\Jothi\\AppData\\Local\\Programs\\Appium Server GUI\\resources\\app\\node_modules\\appium\\build\\lib\\main.js";
	public static String ServerAddress="127.0.0.1";
	@BeforeTest
	public void StartAppiumserver() {
		service=AppiumDriverLocalService.buildService(new AppiumServiceBuilder()
				.usingDriverExecutable(new File(NodeExePath)).withAppiumJS(new File(NodeJsMainPath))
				.withIPAddress(ServerAddress).withArgument(GeneralServerFlag.BASEPATH,"/wd/hub").usingPort(4723)
				.withLogFile(new File("C:\\Users\\Jothi\\OneDrive\\D esktop\\AppiumServerLog.txt")));
		
		System.out.println("Starting Appium Server .....");
		
		service.start();
	}
	
	@SuppressWarnings("unused")
	@Test
	public void lanchApp() throws MalformedURLException, InterruptedException{
		DesiredCapabilities cap= new DesiredCapabilities();
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME,MobilePlatform.ANDROID);
		cap.setCapability(MobileCapabilityType.NO_RESET,true);
        cap.setCapability("appPackage", "io.appium.android.apis");
        cap.setCapability("appActivity", "io.appium.android.apis.ApiDemos");
    	cap.setCapability(MobileCapabilityType.DEVICE_NAME,"emulator-5554");
		
    	AndroidDriver<AndroidElement> driver=new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub/"),cap);
    	Thread.sleep(5000);
    	
    	driver.findElement(By.xpath("//*[contains(@text,'View')]")).click();
    	
    	Thread.sleep(2000);
    	
    	//Scroll down
    	driver.findElement(
    			new AppiumBy.ByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0))"
    	                 +".scrollIntoView(new UiSelector()"+".textMatches(\"" +"TextClock"+"\").instance(0))"));
    	driver.findElement(By.xpath("//*[contains(@text,'TextClock')]")).click();
    	
    	driver.navigate().back();
    	
    	Thread.sleep(2000);
    	
    	//Scroll up
    	driver.findElement(
    			new AppiumBy.ByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0))"
    	                 +".scrollIntoView(new UiSelector()"+".textMatches(\"" +"Buttons"+"\").instance(0))"));
    	driver.findElement(By.xpath("//*[contains(@text,'Buttons')]")).click();
    	
    	driver.quit();
}
	@AfterTest
	public void TearDown() {
		service.stop();
		System.out.println("Appium Server Stop....");
	}
}
