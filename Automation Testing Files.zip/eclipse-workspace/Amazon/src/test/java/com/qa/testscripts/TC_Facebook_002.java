package com.qa.testscripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qa.pages.FacebookPages;

public class TC_Facebook_002 extends TestBase {
	FacebookPages fb;
@Parameters({"Browser","Url"})
@Test
public void Search(String Browser,String Url) throws InterruptedException
{
	fb =new FacebookPages(Driver);
	String url1=Driver.getCurrentUrl();
	Assert.assertEquals(url1,"https://www.facebook.com/","No redirection happened" );
	Driver.manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);
	fb.CreatenewBtn().click();
	Driver.manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);
	fb.Firstname().sendKeys("Test");
	fb.Surname().sendKeys("User");
	fb.Mobileemail().sendKeys("testuser@test.com");
	fb.ReMobileemail().sendKeys("testuser@test.com");
	fb.Password().sendKeys("testPassword");
	
//	Driver.findElement(By.name("firstname")).sendKeys("Test");
//	Driver.findElement(By.name("lastname")).sendKeys("User");
//	Driver.findElement(By.name("reg_email__")).sendKeys("testuser@test.com");
//	Driver.findElement(By.name("reg_passwd__")).sendKeys("testPassword");
	
    Select Day=new Select(fb.Day());
	Day.selectByVisibleText("25");
	Driver.manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);
    Select Month=new Select(fb.Month());
	Month.selectByVisibleText("Oct");
	Driver.manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);
    Select Year=new Select(fb.Year());
	Year.selectByVisibleText("2001");
	Driver.manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);
	
//	Select selDate = new Select(Driver.findElement(By.id("day")));
//	Select selMonth = new Select(Driver.findElement(By.id("month")));
//	Select selYear = new Select(Driver.findElement(By.id("year")));
//	selDate.selectByVisibleText("21");
//	selMonth.selectByVisibleText("Oct");
//	selYear.selectByVisibleText("2001");
	fb.Gender().click();
	Driver.manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);
    fb.Signup().click();
	
}
}

/*
   <test thread-count="5" name="Test 1 Chrome" >
  <parameter name="Browser" value="Chrome"/>
   <classes>
      <class name="com.qa.testscripts.TC_Facebook_002"/>
     </classes>
  </test> <!-- Test --> 
  */
