package com.qa.testscripts;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qa.pages.SnapdealPages;

public class TC_Snapdeal_005 extends TestBase {
		SnapdealPages sd;
	@Parameters({"Browser","Url"})
	@Test
	public void Search(String Browser,String Url) throws InterruptedException
	{
		sd=new SnapdealPages(Driver);

		sd.Signin().click();
		Thread.sleep(1000);
//		Actions action =new Actions(Driver);
//		action.moveToElement(sd.Signin());
		sd.Login().click();
//		Driver.switchTo().frame(sd.Frame());
		Driver.navigate().to("https://www.snapdeal.com/login");
		Thread.sleep(1000);
		sd.Email().sendKeys("jothiprasath2510@gmail.com");
		Thread.sleep(1000);
		sd.Continue1().click();
		Thread.sleep(1000);
	
}
}
