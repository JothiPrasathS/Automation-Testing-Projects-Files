package com.qa.testscripts;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qa.pages.FlipkartPages;

public class TC_Flipkart_003 extends TestBase {
		FlipkartPages fk;
	@Parameters({"Browser","Url"})
	@Test
	public void Search(String Browser,String Url) throws InterruptedException
	{
		fk =new FlipkartPages(Driver);
		fk.CloseButton().click();
		List<WebElement> Alllink =fk.getAlllink(); 
	 	System.out.println("Total Links are : " + Alllink.size());
		for(WebElement LinkUrlText:Alllink) 
		{
			System.out.println("Link Text ::"+LinkUrlText.getText());
			System.out.println("Url Text ::"+LinkUrlText.getAttribute("href"));
		}


}
}
