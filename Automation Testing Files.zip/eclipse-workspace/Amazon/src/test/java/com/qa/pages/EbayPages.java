package com.qa.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EbayPages {
		 WebDriver Driver;
		 
		 @FindBy(xpath="/html[1]/body[1]/header[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]/button[1]")
		 WebElement category;
		 public WebElement Category() {
				return category;
			}
			 
		 @FindBy(xpath="//*[@id=\"gh-sbc\"]/tbody/tr/td[1]/h3[2]/a")
		 WebElement electronics;
		 public WebElement Electronics() {
				return electronics;
			}
		
		 @FindBy(xpath="//*[@id=\"gh-ac\"]")
		 WebElement searchbox;
		 public WebElement Searchbox() {
				return searchbox;
			} 
		 
		 @FindBy(xpath="//*[@id=\"gh-btn\"]")
		 WebElement search;
		 public WebElement Search() {
				return search;
		 }
		 @FindBy(xpath="/html")
		 WebElement all;
		 public WebElement All() {
			 return all;
		 }
	
		 @FindBy(xpath="//*[@id=\"mainContent\"]/div[2]")
		 List<WebElement> Searchitem;
		 public List<WebElement> SearchItem(){
			 return Searchitem;
		 }
		 
		 public EbayPages(WebDriver Driver)
		 {
			 this.Driver=Driver;
			PageFactory.initElements(Driver,this); 
		 }
	}