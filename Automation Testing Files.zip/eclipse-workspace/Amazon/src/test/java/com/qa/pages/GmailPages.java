package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GmailPages {
	
		 WebDriver Driver;
		 
		 @FindBy(id="identifierId")
		 WebElement email;
		 public WebElement Email() {
				return email;
			}
			 

		 @FindBy(name="Passwd")
		 WebElement pass;
		 public WebElement Pass() {
				return pass;
		}
		 
		 @FindBy(xpath="/html/body/div[7]/div[2]/div/div[2]/div[2]/div[1]/div[1]/div/div")
		 WebElement compose;
		 public WebElement Compose() {
				return compose;
		}
		 
		 @FindBy(xpath="//*[@id=\":sy\"]")
		 WebElement to;
		 public WebElement To() {
				return to;
		}
	
		 @FindBy(name="subjectbox")
		 WebElement sub;
		 public WebElement Sub() {
				return sub;
		}
		 
		 @FindBy(xpath="//*[@id=\":q8\"]")
		 WebElement textc;
		 public WebElement Textc() {
				return textc;
		}
		 
		 @FindBy(xpath="//*[@id=\":os\"]")
		 WebElement snd;
		 public WebElement Snd() {
				return snd;
		}
		 public GmailPages(WebDriver Driver)
		 {
			 this.Driver=Driver;
			PageFactory.initElements(Driver,this); 
		 }
}
