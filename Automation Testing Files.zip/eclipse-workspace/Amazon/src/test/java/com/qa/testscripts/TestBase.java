
	package com.qa.testscripts;

	import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.qa.pages.Gmail2Pages;

import io.github.bonigarcia.wdm.WebDriverManager;

	public class TestBase 
	{
		Gmail2Pages gm;
		WebDriver Driver;
		@Parameters({"Browser","Url"})
	  @BeforeClass
	  public void Setup(String Browser,String Url)throws IOException
	  {
		  
		  if(Browser.equalsIgnoreCase("Chrome"))
		  {
			  WebDriverManager.chromedriver().setup();
			  Driver=new ChromeDriver();
		  }
		  else if(Browser.equalsIgnoreCase("Edge"))
		  {
			  WebDriverManager.edgedriver().setup();
			  Driver=new EdgeDriver();
		  }
		  else if(Browser.equalsIgnoreCase("Firefox"))
		  {
			  WebDriverManager.firefoxdriver().setup();
			  Driver=new FirefoxDriver();
		  }
		  gm=new Gmail2Pages(Driver);
		  Driver.manage().window().maximize();
	 	  Driver.manage().deleteAllCookies();
		  Driver.get(Url);
         Driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		
	  }
		@AfterClass
		public void TearDown() 
		{
			Driver.close();
		}
}
