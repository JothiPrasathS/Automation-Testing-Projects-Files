package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FacebookPages { 
	WebDriver Driver;

@FindBy(xpath="/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/form[1]/div[5]/a[1]")
WebElement createnewbtn;
public WebElement CreatenewBtn() {
		return createnewbtn;
	}
	 
@FindBy(xpath="/html[1]/body[1]/div[3]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]")
WebElement firstname;
public WebElement Firstname() {
		return firstname;
	}
	 
@FindBy(xpath="/html[1]/body[1]/div[3]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/input[1]")
WebElement surname;
public WebElement Surname() {
		return surname;
	}
	 
@FindBy(xpath="/html[1]/body[1]/div[3]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/div[1]/div[2]/div[1]/div[1]/input[1]")
WebElement mobileemail;
public WebElement Mobileemail() {
		return mobileemail;
	}

@FindBy(xpath="/html/body/div[3]/div[2]/div/div/div[2]/div/div/div[1]/form/div[1]/div[3]/div/div/div[1]/input")
WebElement remobileemail;
public WebElement ReMobileemail() {
		return remobileemail;
}		 
@FindBy(xpath="/html[1]/body[1]/div[3]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/div[1]/div[4]/div[1]/div[1]/input[1]")
WebElement password;
public WebElement Password() {
		return password;
	}
@FindBy(id="day")
WebElement day;
public WebElement Day() {
		return day;
	}
@FindBy(id="month")
WebElement month;
public WebElement Month() {
		return month;
	}
@FindBy(id="year")
WebElement year;
public WebElement Year() {
		return year;
	}
	
@FindBy(xpath="/html[1]/body[1]/div[3]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/div[1]/div[7]/span[1]/span[2]/label[1]")
WebElement gender;
public WebElement Gender() {
		return gender;
	}

@FindBy(xpath="/html[1]/body[1]/div[3]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/div[1]/div[11]/button[1]")
WebElement signup;
public WebElement Signup() {
		return signup;
	}


public FacebookPages(WebDriver Driver)
{
	 this.Driver=Driver;
	PageFactory.initElements(Driver,this); 
}}
