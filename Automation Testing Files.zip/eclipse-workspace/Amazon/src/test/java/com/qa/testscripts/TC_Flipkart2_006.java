package com.qa.testscripts;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qa.pages.Flipkart2Pages;

public class TC_Flipkart2_006 extends TestBase
	{
		Flipkart2Pages fk;
	@Parameters({"Browser","Url"})
	@Test
	public void Search(String Browser,String Url) throws InterruptedException
	{
		fk=new Flipkart2Pages(Driver);
		fk.Emailphn().sendKeys("testuser@abc.com");
		fk.Password().sendKeys("Test@1234");
		fk.Login().click();
}
}