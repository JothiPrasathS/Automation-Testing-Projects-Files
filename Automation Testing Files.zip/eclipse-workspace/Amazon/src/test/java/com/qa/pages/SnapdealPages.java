package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SnapdealPages {
	 WebDriver Driver;
	 
	 @FindBy(xpath="//*[@id=\"sdHeader\"]/div[4]/div[2]/div/div[3]/div[3]/div/span[1]")
	 WebElement signin;
	 public WebElement Signin() {
			return signin;
		}

		 @FindBy(xpath="/html[1]/body[1]/div[2]/div[4]/div[2]/div[1]/div[3]/div[3]/div[1]/div[1]/div[2]/div[2]/span[2]")
	 WebElement login;
	 public WebElement Login() {
			return login;
	 }
	 
	 @FindBy(xpath="//*[@id=\"userName\"]")
	 WebElement email;
	 public WebElement Email() {
			return email;
	 }
	 
	 @FindBy(xpath="//*[@id=\"checkUser\"]")
	 WebElement continue1;
	 public WebElement Continue1() {
			return continue1;
	 }

	 @FindBy(xpath="//iframe[@id='loginIframe']")
	 WebElement frame;
	 public WebElement Frame() {
			return frame;
	 }
	 
	 public SnapdealPages(WebDriver Driver)
	 {
		 this.Driver=Driver;
		PageFactory.initElements(Driver,this); 
	 }
}
