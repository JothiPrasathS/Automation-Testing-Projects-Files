package com.qa.testscripts;

import org.openqa.selenium.Keys;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qa.pages.GmailPages;

public class TC_Gmail_008 extends TestBase
{
	GmailPages gm;
@Parameters({"Browser","Url"})
@Test
public void Search(String Browser,String Url) throws InterruptedException
{
	gm=new GmailPages(Driver);
    gm.Email().sendKeys("19e216@kce.ac.in"+Keys.ENTER);
    Thread.sleep(8000);
    gm.Pass().sendKeys("9361489543"+Keys.ENTER);
    Thread.sleep(8000);
    gm.Compose().click();
    Thread.sleep(2000);
    gm.To().sendKeys("jothiprasath2510@gmail.com");
    Thread.sleep(2000);
    gm.Sub().sendKeys("Selenium Text");
    Thread.sleep(2000);
    gm.Textc().sendKeys("TC_Gmail_008");
    Thread.sleep(2000);
    gm.Snd().click();
    Thread.sleep(2000);
}
}