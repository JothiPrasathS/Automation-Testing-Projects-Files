package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Flipkart2Pages {
	 WebDriver Driver;
	 
	 @FindBy(xpath="/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input")
	 WebElement emailphn;
	 public WebElement Emailphn() {
			return emailphn;
		}

	 @FindBy(xpath="/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input")
	 WebElement password;
	 public WebElement Password() {
			return password;
	 }
	 
	 @FindBy(xpath="/html/body/div[2]/div/div/div/div/div[2]/div/form/div[4]/button")
		 WebElement login;
		 public WebElement Login() {
				return login;
			}
		 
	 public Flipkart2Pages(WebDriver Driver)
	 {
		 this.Driver=Driver;
		PageFactory.initElements(Driver,this); 
	 }
}
