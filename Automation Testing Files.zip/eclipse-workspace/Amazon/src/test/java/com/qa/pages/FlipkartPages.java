package com.qa.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FlipkartPages {
	 WebDriver Driver;
	 
	 @FindBy(xpath="//button[contains(text(),'✕')]")
	 WebElement closeBtn;
	 public WebElement CloseButton() {
			return closeBtn;
		}
	 
	@FindBy(tagName="a")
	 List<WebElement> Alllink;
	  
	  public List<WebElement> getAlllink(){
	      return Alllink;
	  }

	 public FlipkartPages(WebDriver Driver)
	 {
		 this.Driver=Driver;
		PageFactory.initElements(Driver,this); 
	 }
}
