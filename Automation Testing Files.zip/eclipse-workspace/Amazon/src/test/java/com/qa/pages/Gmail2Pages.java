package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Gmail2Pages {
	 WebDriver Driver;
	 
	 @FindBy(id="identifierId")
	 WebElement email;
	 public WebElement Email() {
			return email;
		}
		 

	 @FindBy(name="Passwd")
	 WebElement pass;
	 public WebElement Pass() {
			return pass;
	} 
	
	 @FindBy(xpath="//*[@id=\":kd\"]")
	 WebElement more;
	 public WebElement More() {
			return more;
	} 
	 
	 @FindBy(xpath="//*[@id=\":kt\"]/div/div[3]/span/a")
	 WebElement category;
	 public WebElement Category() {
			return category;
	} 
	 @FindBy(xpath="//*[@id=\":ku\"]/div/div[3]/span/a")
	 WebElement social;
	 public WebElement Social() {
			return social;
	} 
	 @FindBy(xpath="//*[@id=\":k6\"]/div[1]/div/div[1]")
	 WebElement inbox;
	 public WebElement Inbox() {
		 return inbox;
	 }
	 @FindBy(xpath="/html/body/div[7]/div[2]/div/div[2]/div[5]/div/div/div/div/div[1]/div[2]/div[2]/div[2]/div/span/div[1]/span/span[2]")
	 WebElement totalcount;
	 public WebElement TotalCount() {
		 return totalcount;
	 }
	 @FindBy(xpath="/html/body/div[7]/div[2]/div/div[2]/div[5]/div/div/div/div/div[1]/div[2]/div[2]/div[2]/div/span/div[1]/span/span[1]/span[2]")
	 WebElement ptotalcount;
	 public WebElement PTotalCount() {
		 return ptotalcount;
	 }
	
	 public Gmail2Pages(WebDriver Driver)
	 {
		 this.Driver=Driver;
		PageFactory.initElements(Driver,this); 
	 }
	
	 

}
