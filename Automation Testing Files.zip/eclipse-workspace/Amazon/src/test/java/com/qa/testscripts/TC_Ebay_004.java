package com.qa.testscripts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qa.pages.EbayPages;

public class TC_Ebay_004 extends TestBase {
	EbayPages eb;
	int data=25;
@Parameters({"Browser","Url"})
@Test
public void Search(String Browser,String Url) throws InterruptedException
{
	eb=new EbayPages(Driver);

	eb.Category().click();

	Thread.sleep(1000);
	
	eb.Electronics().click();

	Thread.sleep(2000);
	
	eb.Searchbox().sendKeys("Apple Watches");

	Thread.sleep(2000);
	
	eb.Search().click();

	Thread.sleep(1000);
	
	List<WebElement> listitem= eb.SearchItem();
	for(WebElement item: listitem)
	{
		System.out.println(item.getText());
	}
    System.out.println(eb.All().getText());
	Thread.sleep(2000);
	
	Driver.findElement(By.xpath("//*[@id=\"srp-river-results\"]/ul/li["+(data+1)+"]/div")).click();
	Thread.sleep(2000);
	
	int last=Driver.findElements(By.xpath("//*[@id=\"srp-river-results\"]/ul/li[63]/div[2]/span/span/nav/ol/li")).size();
	for(int i=1;i<=last;i++) {
	Driver.findElement(By.xpath("//*[@id=\"srp-river-results\"]/ul/li[63]/div[2]/span/span/nav/ol/li["+i+"]")).click();
	List<WebElement> listitem2= eb.SearchItem();
	for(WebElement item: listitem2)
	{
		System.out.println(item.getText());
	}
	}
	Thread.sleep(2000);
	
}
}