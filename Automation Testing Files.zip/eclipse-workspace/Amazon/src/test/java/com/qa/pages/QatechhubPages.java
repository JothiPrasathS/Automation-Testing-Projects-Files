package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class QatechhubPages 
{
	 WebDriver Driver;
	 
	 @FindBy(xpath="")
	 WebElement SearchBtn;
	 public WebElement SearchButton() {
			return SearchBtn;
		}
		 
	 public QatechhubPages(WebDriver Driver)
	 {
		 this.Driver=Driver;
		PageFactory.initElements(Driver,this); 
	 }
}





