package com.qa.testscripts;

import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qa.pages.DragandDropPages;

public class TC_DragandDrop_007 extends TestBase
{
	DragandDropPages dd;
@Parameters({"Browser","Url"})
@Test
public void Search(String Browser,String Url) throws InterruptedException
{
dd=new DragandDropPages(Driver);	
Driver.switchTo().frame(dd.Iframe());
Actions action= new Actions(Driver);
String beforecolor=dd.Target().getCssValue("color");
System.out.println("beforecolor :"+beforecolor);
action.moveToElement(dd.Source()).clickAndHold().moveToElement(dd.Target()).release().build().perform();
String aftercolor=dd.Target().getCssValue("color");
Assert.assertNotEquals(beforecolor, aftercolor);
System.out.println("aftercolor :"+aftercolor);
}
}
