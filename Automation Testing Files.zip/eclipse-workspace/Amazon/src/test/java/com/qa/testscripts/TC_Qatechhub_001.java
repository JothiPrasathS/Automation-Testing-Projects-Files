package com.qa.testscripts;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.qa.pages.QatechhubPages;

public class TC_Qatechhub_001 extends TestBase
{
	QatechhubPages qh;
@Parameters({"Browser","Url"})
@Test
public void Search(String Browser,String Url) throws InterruptedException
{
	qh=new QatechhubPages(Driver);
	
	String title1=Driver.getTitle();
	
	Assert.assertEquals(title1,"QA Automation Tools Trainings and Tutorials | QA Tech Hub");
	
    Driver.navigate().to("https://www.facebook.com");
	String url1=Driver.getCurrentUrl();
	System.out.println("Current URL :: " + url1);
    Driver.navigate().back();
    Driver.navigate().forward();
    Driver.navigate().refresh();
}

}
/*
    <test thread-count="5" name="Test 1 Firefox" >
  <parameter name="Browser" value="Firefox"/>
   <classes>
      <class name="com.qa.testscripts.TC_Qatechhub_001"/>
     </classes>
  </test> <!-- Test --> 
 */

