package com.qa.testscripts;

import java.text.NumberFormat;
import java.text.ParseException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qa.pages.Gmail2Pages;

public class TC_Gmail2_009 extends TestBase
{
	Gmail2Pages gm;
	int row=14;
@SuppressWarnings("static-access")
@Parameters({"Browser","Url"})
@Test
public void Search(String Browser,String Url) throws InterruptedException, ParseException
{
	gm=new Gmail2Pages(Driver);
	gm.Email().sendKeys("19e216@kce.ac.in"+Keys.ENTER);
    Thread.sleep(8000);
    gm.Pass().sendKeys("9361489543"+Keys.ENTER);
    Thread.sleep(8000);
    gm.More().click();
    Thread.sleep(4000);
    gm.Category().click();
    Thread.sleep(4000);
    gm.Social().click();
    Thread.sleep(4000);
    
    WebElement social= Driver.findElement(By.xpath("//*[@id=\":ku\"]/div/div[3]/span/a"));
    Assert.assertEquals(gm.Social(),social );
    Thread.sleep(2000);
    
    String num= gm.TotalCount().getText();
    System.out.println("Total count="+num);
    Thread.sleep(2000);
    
    NumberFormat numformat= NumberFormat.getNumberInstance();
    Number number= numformat.parse(num);
    Thread.sleep(2000);
    
    num=number.toString();
    int n=Integer.parseInt(num);
    System.out.println("Total count="+n);
    Thread.sleep(2000);
    
    String pcount=gm.PTotalCount().getText();
    int np=Integer.parseInt(pcount);
    System.out.println("Total count per page="+np);
    Thread.sleep(2000);
    
    
    gm.Inbox().click();
    Thread.sleep(2000);
    
    String specifictitle=Driver.findElement(By.xpath("/html/body/div[7]/div[2]/div/div[2]/div[5]/div/div/div/div/div[2]/div/div[1]/div/div[1]/div[5]/div[1]/div/table/tbody/tr["+row+"]/td[4]/div[2]/span/span")).getText();
	System.out.println("Title of mail :"+specifictitle); 
    Thread.sleep(2000);
    
    String specificcontent=Driver.findElement(By.xpath("/html/body/div[7]/div[2]/div/div[2]/div[5]/div/div/div/div/div[2]/div/div[1]/div/div[1]/div[5]/div[1]/div/table/tbody/tr["+row+"]/td[5]/div/div/div/span/span")).getText();
    System.out.println("Cotent of mail :"+specificcontent);
    Thread.sleep(2000);
    
    for(int i=1;i<=np;i++)
    {
    	String title=Driver.findElement(By.xpath("/html/body/div[7]/div[2]/div/div[2]/div[5]/div/div/div/div/div[2]/div/div[1]/div/div[1]/div[5]/div[1]/div/table/tbody/tr["+i+"]/td[4]/div[2]/span/span")).getText();
    	System.out.println("Title of mail :"+title); 
    }
    Thread.sleep(2000);
    
 	for(int i=1;i<=np;i++)
    {
        String content=Driver.findElement(By.xpath("/html/body/div[7]/div[2]/div/div[2]/div[5]/div/div/div/div/div[2]/div/div[1]/div/div[1]/div[5]/div[1]/div/table/tbody/tr["+i+"]/td[5]/div/div/div/span/span")).getText();
        System.out.println("Cotent of mail :"+content);
    }
    Thread.sleep(2000);
}
}