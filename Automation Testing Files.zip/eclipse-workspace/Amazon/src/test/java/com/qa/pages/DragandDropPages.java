package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DragandDropPages {
	 WebDriver Driver;

	 @FindBy(xpath="//*[@id=\"content\"]/iframe")
	 WebElement iframe;
	 public WebElement Iframe() {
			return iframe;
		}
	 
	 @FindBy(id="draggable")
	 WebElement source;
	 public WebElement Source() {
			return source;
		}
		 
	 @FindBy(id="droppable")
	 WebElement target;
	 public WebElement Target() {
			return target;
		}
	 public DragandDropPages(WebDriver Driver)
	 {
		 this.Driver=Driver;
		PageFactory.initElements(Driver,this); 
	 }
}
