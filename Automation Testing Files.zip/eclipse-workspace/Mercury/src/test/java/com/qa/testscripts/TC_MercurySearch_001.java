package com.qa.testscripts;

import java.io.IOException;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.qa.pages.Mercurypages;

public class TC_MercurySearch_001 extends TestBase_1 {
	
	Mercurypages pages;
	
	@Parameters({"Browser","Url"})
	@Test
	public void Test() throws InterruptedException, IOException
	{
		pages=new Mercurypages(Driver);
		pages.Username().sendKeys(prop.getProperty("username"));
		Thread.sleep(1500);
		pages.Password().sendKeys(prop.getProperty("password"));
		Thread.sleep(1500);
		pages.Submit().click();
		Thread.sleep(1500);
		
	}
	
	}
		