package com.qa.pages;

public class Cleartrippages {

}
