package dummy;

import java.util.Scanner;

public class Sum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		int ct=0;
		for(int i=0;i<n;i++) {
			if(arr[i]%2==0) {
				ct+=arr[i];
			}
		}
		System.out.println("The sum of even numbers in the array is "+ct);

	}

}
