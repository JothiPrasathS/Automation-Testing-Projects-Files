/**
 * 
 */
/**
 * @author Joe
 *
 */
module Samples {
}