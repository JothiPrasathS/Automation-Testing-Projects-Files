package com.qa.testscripts;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Netflix {
public static void main(String[] args) throws InterruptedException
{
	String browser="Chrome";
	ChromeDriver driver=null;
	if(browser.equalsIgnoreCase("Chrome"))
	{
		System.setProperty("webdriver.chrome.driver","D:\\Virtusa\\chromedriver_win32\\chromedriver.exe");
	    driver=new ChromeDriver();
	}
	driver.get("http://www.netflix.com");
	driver.manage().window().maximize();
    WebElement sigin=driver.findElement(By.xpath("//*[@id=\"appMountPoint\"]/div/div/div/div/div/div[1]/div/a"));
	sigin.click();
	 WebElement email=driver.findElement(By.id("id_userLoginId"));
	    email.sendKeys("rdeepak4u@gmail.com");
	    
	 WebElement password=driver.findElement(By.id("id_password"));
	 password.sendKeys("divya@12");
	 
	 WebElement enter=driver.findElement(By.xpath("//*[@id=\"appMountPoint\"]/div/div[3]/div/div/div[1]/form/button"));
	 enter.click();
	 Thread.sleep(5000);
	 WebElement g=driver.findElement(By.xpath("//*[@id=\"appMountPoint\"]/div/div/div[1]/div[1]/div[2]/div/div/ul/li[4]/div/a"));
	 g.click();
	 
	 Thread.sleep(2000);
	 
	 WebElement s=driver.findElement(By.xpath("//*[@id=\"appMountPoint\"]/div/div/div[1]/div[1]/div[1]/div/div/div/div[1]/div"));
	 s.click();
	 
	 Thread.sleep(2000);
	 
	 WebElement t=driver.findElement(By.id("searchInput"));
	 t.sendKeys("After Ever Happy");
	 
	 driver.findElement(By.id("searchInput")).sendKeys(Keys.ENTER);
	 
	 Thread.sleep(2000);
	 
	 driver.get("https://www.netflix.com/watch/81397456?trackId=255824129&tctx=0%2C0%2CNAPA%40%40%7Ca1ac042f-c4ae-40ad-847b-ff9188eaf2a1-482562638_titles%2F1%2F%2FAfter%20Ever%20Happy%2F0%2F0%2CNAPA%40%40%7Ca1ac042f-c4ae-40ad-847b-ff9188eaf2a1-482562638_titles%2F1%2F%2FAfter%20Ever%20Happy%2F0%2F0%2Cunknown%2C%2Ca1ac042f-c4ae-40ad-847b-ff9188eaf2a1-482562638%7C1%2C%2C");
	
	 WebElement ck=driver.findElement(By.xpath("//*[@id=\"appMountPoint\"]/div/div/div[1]/div[2]"));
	 ck.click();
	 
	 WebElement p=driver.findElement(By.xpath("/div/div[1]/div/div[1]/div/button/div/svg/path"));
	 p.click();
	 
	 driver.close();
	 
	 Thread.sleep(20000);
	 
	 driver.close();
}
}

