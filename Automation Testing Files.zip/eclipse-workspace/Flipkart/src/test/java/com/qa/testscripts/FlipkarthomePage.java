package com.qa.testscripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FlipkarthomePage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String browser="Chrome";
     ChromeDriver driver=null;
     if(browser.equalsIgnoreCase("Chrome")) {
    	 System.setProperty("webdriver.chrome.driver","D:\\Virtusa\\chromedriver_win32\\chromedriver.exe");
         driver=new ChromeDriver();	

     }
     driver.get("http://www.flipkart.in");
     String title=driver.getTitle();
     System.out.println(title);
     
     WebElement search=driver.findElement(By.name("q"));
     search.sendKeys("Samsung Mobile Phone");
     
 	 driver.close();
 	
	}

}