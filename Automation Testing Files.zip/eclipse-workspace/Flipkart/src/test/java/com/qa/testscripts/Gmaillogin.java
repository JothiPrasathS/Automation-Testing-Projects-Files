package com.qa.testscripts;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Gmaillogin {
public static void main(String[] args) {
	String browser="Firefox";
	FirefoxDriver driver = null;
	if(browser.equalsIgnoreCase("Firefox"))
	{
		System.setProperty("webdriver.gecko.driver","D:\\Virtusa\\geckodriver-v0.31.0-win64\\geckodriver.exe");
        driver=new FirefoxDriver();	
	}
	   
	   
	
	driver.get("http://gmail.com");
	
    String title1= driver.getTitle();
    System.out.println(title1);
    
    WebElement search=driver.findElement(By.id("identifierId"));
    search.sendKeys("19e216@kce.ac.in");
    
    
    driver.findElement(By.id("identifierId")).sendKeys(Keys.ENTER);
    String title11= driver.getTitle();
    System.out.println(title11);
    
    WebElement pass=driver.findElement(By.id("password"));
    pass.sendKeys("9361489543");
    
    driver.findElement(By.id("password")).sendKeys(Keys.ENTER);
   
    //Thread.sleep(5000);
}
}
